## Plot scripts
These scripts were used to plot the results. <br><br>
To avoid redundancy, we simply show one example for each plot method.